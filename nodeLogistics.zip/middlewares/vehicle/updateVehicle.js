/**
 * Update vehicle and save it to db
 */

module.exports = function (objectrepository) {
    return function (req, res, next) {

        return next();
    };
};